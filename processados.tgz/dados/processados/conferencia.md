# Conferência: setembro de 2026

- Produção total Brasil: 6.116 mil boe/d (+1,9% no mês, +19,7% em 12 meses)
- Petróleo Brasil: 4.708 mil bbl/d (+2,1% no mês, +20,4% em 12 meses)
- Gás natural: 223,9 milhões m³/d
- Poços ativos: 6.738
- Campos: 282 · Operadoras: 42

## Resultado: PUBLICAR

### Avisos
- 12 campos sem operador identificado (0,0% da produção em boe). Preencha dados/manuais/operador_por_campo.csv: JAPIIM (Amazonas, AM): 692 boe/d; AnC_ARGONAUTA_ME1 (Campos, ES): 56 boe/d; Rio Joanes (Recôncavo, BA): 48 boe/d; PIAÇABUÇU (Alagoas, AL): 20 boe/d; MOSQUITO (Espírito Santo, ES): 20 boe/d; Camaçari (Recôncavo, BA): 18 boe/d; BATUÍRA (Espírito Santo, ES): 5 boe/d; Tanatau (Potiguar, RN): 5 boe/d; MURIQUI (Espírito Santo, ES): 4 boe/d; SAÍRA (Espírito Santo, ES): 1 boe/d; PARAMIRIM DO VENCIMENTO (Recôncavo, BA): 0 boe/d; DÓ-RÉ-MI (Sergipe, SE): 0 boe/d
- A ANP não publicou dados de terra em: abril de 2026, julho de 2026. Esses meses aparecem como lacuna nos gráficos.
- Campos novos no mês: ANDORINHA, ARABAIANA, ATALAIA SUL, JAPIIM, MOSQUITO, PORTO CARÃO, SAÍRA, Tanatau
- Campos que sumiram no mês: PERIQUITO NORTE, TROVOADA, VALE DO QUIRICÓ

### Operadoras (mil boe/d · petróleo mil bbl/d)
Petrobras 5.325,2 · 4.076,8; PRIO 223,0 · 210,6; Equinor Brasil 191,4 · 144,2; TotalEnergies EP 87,3 · 69,7; Brava Energia 80,4 · 68,1; Shell Brasil 37,8 · 34,2; Eneva 34,8 · 0,3; Trident Energy 21,8 · 19,8; PetroRecôncavo 20,8 · 11,6; Karoon Brasil 20,5 · 19,0; Perenco Brasil 18,8 · 18,2; Origem Energia 18,1 · 5,2; Carmo 12,4 · 11,9; Seacrest Petróleo 8,0 · 7,2; BW Energy 6,8 · 6,4; SPE Tiêta 3,0 · 2,8; Alvopetro 1,8 · 0,1; Recôncavo Energia SP 1,0 · 0,0; Não identificado 0,9 · 0,2; Mandacaru Energia 0,6 · 0,5; Capixaba Energia 0,5 · 0,4; Petrosynergy 0,3 · 0,3; Bgm 0,3 · 0,3; Barra Bonita 0,2 · 0,0; Petrom 0,2 · 0,2; Imetame 0,2 · 0,2; Níon Energia 0,1 · 0,1; Nova Petróleo 0,1 · 0,1; Petroil 0,1 · 0,1; Petroborn 0,0 · 0,0; Petro-Victory 0,0 · 0,0; Phoenix Óleo & Gás 0,0 · 0,0; Ntf 0,0 · 0,0; Energizzi Energias 0,0 · 0,0; Vipetro 0,0 · 0,0; Guto & Cacal 0,0 · 0,0; EPG Brasil 0,0 · 0,0; Tarmar 0,0 · 0,0; Nord 0,0 · 0,0; Central Resources 0,0 · 0,0; Brasil Refinarias 0,0 · 0,0; Slim Drilling 0,0 · 0,0

### Estados (mil boe/d · % do Brasil)
RJ 5.127,4 · 83,8%; SP 430,4 · 7,0%; ES 312,6 · 5,1%; AM 99,6 · 1,6%; BA 50,5 · 0,8%; RN 33,7 · 0,6%; MA 30,3 · 0,5%; AL 18,1 · 0,3%; SE 12,7 · 0,2%; CE 0,8 · 0,0%; PR 0,2 · 0,0%

### Bacias (mil boe/d)
Santos 4.920,3; Campos 931,8; Solimões 94,4; Recôncavo 36,6; Potiguar 34,5; Parnaíba 30,3; Espírito Santo 18,3; Alagoas 18,1; Camamu 13,6; Sergipe 12,7; Amazonas 5,2; Tucano Sul 0,3; Paraná 0,2; Barreirinhas 0,0

Antes de divulgar, confira 3 números contra o Painel Dinâmico da ANP.
